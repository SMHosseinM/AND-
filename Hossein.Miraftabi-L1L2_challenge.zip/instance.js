const newCandidates = [
  { name: "Kerrie", skills: ["JavaScript", "Docker", "Ruby"] },
  { name: "Mario", skills: ["Python", "AWS"] },
  { name: "Jacquline", skills: ["JavaScript", "Azure"] },
  { name: "Kathy", skills: ["JavaScript", "Java"] },
  { name: "Anna", skills: ["JavaScript", "AWS"] },
  { name: "Matt", skills: ["PHP", "AWS"] },
  { name: "Matt", skills: ["PHP", ".Net", "Docker"] },
];

const candidatesTable = document.getElementById("candidates_example");
let newCandidatesTable = candidatesTable.cloneNode(true);

removeRowsFromTable(newCandidatesTable);
let newTbody = newCandidatesTable.getElementsByTagName('tbody')[0];

let filteredCandidates = filterCandidateBySkill(newCandidates, 'JavaScript')
addCandidatesToTable(newTbody, filteredCandidates)

document.body.appendChild(newCandidatesTable);

    
// Second table with Docker skill
newCandidatesTable = candidatesTable.cloneNode(true);

removeRowsFromTable(newCandidatesTable);
newTbody = newCandidatesTable.getElementsByTagName('tbody')[0];

filteredCandidates = filterCandidateBySkill(newCandidates, 'Docker')
addCandidatesToTable(newTbody, filteredCandidates)

document.body.appendChild(newCandidatesTable);

// Third table with AWS skill
newCandidatesTable = candidatesTable.cloneNode(true);

removeRowsFromTable(newCandidatesTable);
newTbody = newCandidatesTable.getElementsByTagName('tbody')[0];

filteredCandidatesWithAWSSkill = filterCandidateBySkill(newCandidates, 'AWS')
addCandidatesToTable(newTbody, filteredCandidatesWithAWSSkill)

document.body.appendChild(newCandidatesTable);